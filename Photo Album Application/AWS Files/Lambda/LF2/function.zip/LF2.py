

import math
import dateutil.parser
import datetime
import time
import os
import logging
import boto3

from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3
import json



logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


""" --- Helpers to build responses which match the structure of the necessary dialog actions --- """


def get_slots(intent_request):
    return intent_request['currentIntent']['slots']


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }


def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }


""" --- Helper Functions --- """


def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            "isValid": is_valid,
            "violatedSlot": violated_slot,
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }


def isvalid_date(date):
    try:
        datetime.datetime.strptime(date, '%Y-%m-%d')
        return True
    except ValueError:
        return False


def search(intent_request):
    print(intent_request)
    tags = []
    slots = get_slots(intent_request)
    for t in slots:
        if slots[t]:
            tags.append(slots[t])

    # return close(intent_request['sessionAttributes'],
    #              'Fulfilled',
    #              {'contentType': 'PlainText',
    #               'content': "'"+str(tags)+"'"})
    return es(tags)



def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """

    logger.debug('dispatch userId={}, intentName={}'.format(intent_request['userId'], intent_request['currentIntent']['name']))

    intent_name = intent_request['currentIntent']['name']

    if intent_name == 'SearchIntent':
        return search(intent_request)

    raise Exception('Intent with name ' + intent_name + ' not supported')


""" --- Main handler --- """

def es(labels):
    host = 'vpc-photos-zd4pzjklhsh2hmg4rytiiplil4.us-east-1.es.amazonaws.com'# For example, my-test-domain.us-east-1.es.amazonaws.com
    region = 'us-east-1' # e.g. us-west-1

    service = 'es'
    credentials = boto3.Session().get_credentials()
    print(credentials)
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    '''
    awsauth = AWSRequestsAuth(aws_access_key='',
                           aws_secret_access_key='',
                           aws_host=host,
                           aws_region=region,
                           aws_service=service)
    '''
    es = Elasticsearch(
        hosts = [{'host': host, 'port': 443}],
        http_auth = (),
        use_ssl = True,
        verify_certs = True,
        connection_class = RequestsHttpConnection,
        timeout=3000
    )

    # document ={
    # "objectKey": "my-photo1.jpg",
    # "bucket": "my-photo-bucket",
    # "createdTimestamp": "2018-11-05T12:40:02",
    # "labels": ["dog","park"]
    # }
    #
    # es.index(index="photos", doc_type="_doc", id=1, body=document)
    for label in labels:
        
    query={
    "query" : {
        "terms" : {
            "labels" : labels
        }
    }
    }
    res = es.search(body=query)
    results = []
    #print(res['hits']['hits'])
    for r in res['hits']['hits']:
        r=r["_source"]
        results.append({'url':r['bucket']+'/'+r['objectKey'],'labels':r['labels']})
    return results

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    """
    # By default, treat the user request as coming from the America/New_York time zone.
    os.environ['TZ'] = 'America/New_York'
    time.tzset()
    logger.debug('event.bot.name={}'.format(event['bot']['name']))

    results = dispatch(event)

    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Origin": "*"
        },
        'body': json.dumps({
            'results': results

        })
    }
